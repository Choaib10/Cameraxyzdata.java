// Last time updated at April 27, 2015, 08:32:23

// Muaz Khan         - www.MuazKhan.com
// MIT License       - www.WebRTC-Experiment.com/licence
// Documentation     - github.com/muaz-khan/DataChannel
// ______________
// DataChannel.js

'use strict';

(function() {
