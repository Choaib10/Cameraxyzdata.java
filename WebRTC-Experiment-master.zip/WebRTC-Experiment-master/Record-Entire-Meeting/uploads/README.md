# Record Entire Meeting using Pure JavaScript API!

* Uploads directory.

## License

[Record-Entire-Meeting](https://github.com/streamproc/Record-Entire-Meeting) library is released under [MIT licence](https://www.webrtc-experiment.com/licence/). Copyright (c) [Muaz Khan](http://www.MuazKhan.com/).
