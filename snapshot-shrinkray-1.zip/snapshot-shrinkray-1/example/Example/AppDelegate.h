//
//  AppDelegate.h
//  Example
//
//  Created by Felix Krause on 10.11.14.
//  Copyright (c) 2014 Felix Krause. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

