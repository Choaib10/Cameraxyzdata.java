module Snapshot
  VERSION = "0.3.3"
end
